﻿<!DOCTYPE html>

<html lang="en">
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>dbs project </title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
       <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
 </head>
<body>
     <!-- NAV SECTION -->
         <div class="navbar navbar-inverse navbar-fixed-top">
       
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#"> DAT'MART</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#home-sec">HOME</a></li>
					
                    <li><a href="#projects">ABOUT PROJECT</a></li>
                    <li><a href="#contact">CONTACT</a></li>
					<li><a href="log_user.php">LOGIN</a></li>
                </ul>
            </div>
           
        </div>
    </div>
     <!--END NAV SECTION -->
    
    <!--HOME SECTION-->
     
    <div id="home-sec">   
    <div class="container"  >
        <div class="row text-center">
            <div  class="col-md-12" >
         <div id="carousel-example" class="carousel slide" data-ride="carousel">

                    <div class="carousel-inner">
                        <div class="item active">

                            <img src="assets/img/nust.jpg" alt="" />
                            <div class="carousel-caption" >
                                <h4 class="back-light">Welcome to DAT' MART.</h4>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets/img/nust4.jpg" alt="" />
                            <div class="carousel-caption ">
                                <h4 class="back-light">Welcome to DAT' MART.</h4>
                            </div>
                        </div>
                        <div class="item">
                            <img src="assets/img/nust3.jpg" alt="" />
                            <div class="carousel-caption ">
                                <h4 class="back-light">Welcome to DAT' MART.</h4>
                            </div>
                        </div>
                    </div>

                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example" data-slide-to="1"></li>
                        <li data-target="#carousel-example" data-slide-to="2"></li>
                    </ol>
                </div>
                 
            </div>
        </div>
    </div>
         </div>
    
    
    <section  >
        <div class="container">
            
	
         <div class="row text-center">
             <div class="icon-big" >
                 <i class="fa fa-fax fa-4x"></i>
                  <h1><a href = "nust.html"> Choose Your Options</a> </h1>
                      <p>
				

			  <form method="post" action="nust.php" id="filter_form" >  
					  
					  <div style="margin-left: 30px; margin-top: 5px">
        <div style="position: relative;">
            <select name = "NUST" id = "university" required onchange="validate1()" onclick="validate1()" style="position: absolute; top: 10px; left: 150px;">
                    <option disabled selected value=""/>Choose
					<option value="NUST" name = "nust">NUST</option>
                 
            </select>
			
			 <select name = "Concordia" id="cafe" disabled onclick="validate2()" onchange="valaidate2()" style="position: absolute; top: 10px; left: 500px;"  required  >
						<option disabled selected value=""/>Choose
                    <option value="CONCORDIA I">Concordia I</a></option>
                    <option value="CONCORDIA II">Concordia II</a></option>
			
            </select>
			
			<select  name = "shop_name" id="shop" disabled required style="position: absolute; top: 10px; left: 850px;">
				<option selected disabled value=""/>Choose
				<option value="mini mart"><a href = "#">Mini mart</a></option>
				<option value="book shop"><a href = "#">Book shop</a></option>
				<option value="barbar shop"><a href = "#">Barbar shop</a></option>
				<option value="tailor shop"><a href = "#">Tailor shop</a></option>
				<option value="ice cream shop"><a href = "#">Ice cream shop</a></option>				
            </select>
			<script language="JavaScript" type="text/javascript">
			function validate1()
			{
				var e=document.getElementById("university");
				var opt=e.options[e.selectedIndex].value;
				if (opt=="NUST")
				{
					var e=document.getElementById("cafe").disabled=false;
					var e=document.getElementById("shop").disabled=true;
				}
				// else
				// {
					// var e=document.getElementById("cafe").disabled=true;
				// }
			}
			function validate2()
			{
				var e=document.getElementById("cafe");
				var opt=e.options[e.selectedIndex].value;
				if (opt=="CONCORDIA I" || opt=="CONCORDIA II")
				{
					var e=document.getElementById("shop").disabled=false;
				//var e=document.getElementById("room").disabled=true;
				//var e=document.getElementById("batch").disabled=true;
				}
				// else
				// {
					// var e=document.getElementById("hostel").disabled=false;
					// var e=document.getElementById("room").disabled=false;
					// var e=document.getElementById("batch").disabled=false;
				// }
			}
			</script>
			<input type="submit" name="Submit"  style="margin-top:70px;margin-left:-50px;" value="Filter" class="btn btn-primary btn-filter" style="margin-top:-10px;" />
			
        </div>
    </div>
				</form>
			  		
        </div>
    </section>

	
	
	
	
	
	
	
	
	
	
	
	
	
     <!--END HOME SECTION-->


    <div class="container">
        <div class="row text-center">
             <span class="line-sep ">
        ----------X------------X----------X-------------
    </span>
        </div>
    </div>
   
 <!--PROJECTS SECTION-->

      <section  id="projects">
           <div class="container">
<div class="row text-center">
                <div class="text-center">
                    <div class=" alert-info">
                            <h4 style = "background-color:lightgreen">About Project</h4>
                       <p>
This project has been implemented at NUST level. Purpose was to facilitate the students
Click to see which shops are open what is available?
                           
                        </br>   </br>
						   </p>
                            
                    </div>
                                       <div class="text-center">
					  <div class="carousel-inner">
                        <div class="item active">
                     <h4>Concordia I</h4>

                            <img src="assets/img/nust.jpg" alt="" />
                            <div class="carousel-caption" >
                            </div>
                        </div></div>
                       <p>
Rough words:  This project has been implemented at nust level. Purpose was to facilitate the students
Click to see which shops are open. and what is available
                            </p>  
                         
                    </div>
                   
                   <div class="text-center">
					  <div class="carousel-inner">
                        <div class="item active">
                     <h4>Concordia II</h4>

                            <img src="assets/img/nust4.jpg" alt="" />
                            <div class="carousel-caption" >
                            </div>
                        </div></div>
                       <p>
Rough words:  This project has been implemented at nust level. Purpose was to facilitate the students
Click to see which shops are open. and what is available
                            </p>  

                    </div>
                </div>
                  </div>
               </div>
      </section>

    <!--END PROJECTS SECTION-->
    <div class="container">
        <div class="row text-center">
             <span class="line-sep ">
        ----------X------------X----------X-------------
    </span>
        </div>
    </div>
    <!--ABOUT SECTION-->
    <section  id="about">
           <div class="container">
<div class="row text-center">
                <div class="text-center">
                   
                    <div class="col-md-4 col-sm-4 ">
                        <img class="img-circle" src="assets/img/team1.jpg" alt="">
                           <h3><strong>Abdur Rafay Butt</strong> </h3>
                       <p>
Student at National University of Sciences and Technology</p>
<p>Software Engineering at SEECS </p>
                            
                            
                    </div>
					                    <div class="col-md-4 col-sm-4 ">
                        <img class="img-circle" src="assets/img/team2.jpg" alt="">
                           <h3><strong>Muhammad Saleem</strong> </h3>
                       <p>
Student at National University of Sciences and Technology</p>
<p>Software Engineering at SEECS </p>
                            
                    </div>
                   
                    <div class="col-md-4 col-sm-4 ">
                        <img class="img-circle" src="assets/img/team3.jpg" alt="">
                           <h3><strong>Ahmad Sarfraz Bajwa</strong> </h3>
                       <p>
Student at National University of Sciences and Technology</p>
<p>Software Engineering at SEECS </p>
                          
                    </div>
                     <div class="col-md-4 col-sm-4 alert-success">
                            <h4>Who We Are ?</h4>
                       <p>
A team who can work together
                            </p>
                            
                            
                    </div>
                </div>
                  </div>
               </div>
      </section>
    <!--END ABOUT SECTION-->
    <div class="container">
        <div class="row text-center">
             <span class="line-sep ">
        ----------X------------X----------X-------------
    </span>
        </div>
    </div>
    <!--CONTACT SECTION-->
    <section  id="contact">
           <div class="container">
<div class="row text-center">
                <div class="text-center">
                    <div class="col-md-6 col-sm-6">
                   <iframe class="cnt" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2999841.293321206!2d-75.80920404999999!3d42.75594204999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew+York!5e0!3m2!1sen!2s!4v1395313088825" s=""></iframe>

                </div>
                   <div class="col-md-6 col-sm-6 alert-danger">
                            <h4>OUR LOCATION</h4>
                 
                    <p>
                         <strong> Address: </strong> &nbsp;NUST University H-12 Sector Islamabad , Pakistan, Pin-000000.  
                        <br>
                                      
                    </p>
                        <div class="row">
                            <div class="col-md-6 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" required="required" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" required="required" placeholder="Email address">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <textarea name="message" id="message" required="required" class="form-control" rows="3" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-danger">Submit Request</button>
                                </div>
                            </div>
                        </div>
                            
                            
                    </div>
                    
                     
                </div>
                  </div>
               </div>
      </section>
    <!--END CONTACT SECTION-->
  
    <!--FOOTER SECTION -->
    <div id="footer">
        2014 www.yourdomain.com | All Right Reserved  
         
    </div>
    <!-- END FOOTER SECTION -->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.min.js"></script>  
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    </body>
</html>
