

<?php


   if( isset($_POST['Submit']))
  {
	$area = $_POST['NUST'];
	$C = $_POST['Concordia'];
    $shop = $_POST['shop_name'];

echo '<h1>' . "Welcome to" . '</h1>';
				echo "<div><table border='1' bordercolor='blue' bgcolor='lightgreen' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
				echo "<tr style='padding:10px;'>
				        <th style='padding:10px;'>Area</th>
						<th style='padding:10px;'>Market</th>
						<th style='padding:10px;'>Shop</th>

				</tr>";
			echo "<tr style='vertical-align:top;padding:10px;'>
								<td style='padding:10px;'>".$area."</td>
								<td style='padding:10px;'>".$C."</td>
								<td style='padding:10px;'>".$shop."</td>
								</tr>";
			echo "</table></div>";
   }
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "datmart";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$shop_query = "SELECT s_name FROM shop where s_name = '$shop'";
$shop_value = $conn->query($shop_query);
$row = mysqli_fetch_assoc($shop_value);
$shop_name = $row['s_name'];
$market_query = "SELECT m_name FROM market where m_name ='$C'"; 
$market_value = $conn->query($market_query);
$row = mysqli_fetch_assoc($market_value);
$market_name = $row['m_name'];

if($area=='NUST' and $C==$market_name)
{
	

	if ( $shop == $shop_name and ($shop=='mini mart' or $shop=='book shop'))
  {


$sql = "SELECT p_name,type_name, price, quantity 
FROM  market join shop using(market_id) join keeps using(shop_id)
join product using(product_id)
join typ using(type_id)
where s_name = '$shop' and  m_name = '$C'
order by type_name
";
$result = $conn->query($sql);

$sql1 = "SELECT status FROM shop where S_name = '$shop'";
$result1 = $conn->query($sql1);
   	   //mysqli_result_2_table($result, '100%');

if ($result1->num_rows > 0) {

	   
		echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
		echo "<tr style='padding:10px;'>
		<th style='padding:10px;'>Status</th>
		</tr>";
		$row1 = $result1->fetch_assoc();

    echo "<tr style='vertical-align:top;padding:10px;'>
					<td style='padding:10px;'>".$row1['status']."</td></tr>";
echo "</table></div>";

}
if ($result->num_rows > 0) {

		echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
	
	echo "<tr style='padding:10px;'>
		<th style='padding:10px;'>Product</th>
		<th style='padding:10px;'>Type</th>
		<th style='padding:10px;'>Price</th>
		<th style='padding:10px;'>Quantity</th>
		</tr>";

		

  while($row = $result->fetch_assoc()) {
		
		
		
echo "<tr style='vertical-align:top;padding:10px;'>
					<td style='padding:10px;'>".$row['p_name']."</td>
					<td style='padding:10px;'>".$row['type_name']."</td>
					<td style='padding:10px;'>".$row['price']."</td>
					<td style='padding:10px;'>".$row['quantity']."</td>
					</tr>";
		
		
		
	
            }
echo "</table></div>";

       }

   }

   
   
   	if ( $shop == $shop_name and ($shop=='barbar shop' or $shop=='ice cream shop' or $shop == 'tailor shop'))
  {



$sql = "SELECT ser_name, charge
FROM  market join shop using(market_id) join provide using(shop_id)
join service using(service_id)

where s_name = '$shop' and  m_name = '$C'";
$result = $conn->query($sql);

$sql1 = "SELECT status FROM shop where s_name = '$shop'";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {

    
		echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
		echo "<tr style='padding:10px;'>
		<th style='padding:10px;'>Status</th>
		</tr>";
		$row1 = $result1->fetch_assoc();

    echo "<tr style='vertical-align:top;padding:10px;'>
					<td style='padding:10px;'>".$row1['status']."</td></tr>";
echo "</table></div>";
	
	
}
if ($result->num_rows > 0) {
	  	echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
	
	echo "<tr style='padding:10px;'>
		<th style='padding:10px;'>Service</th>
		<th style='padding:10px;'>Charges</th>

		</tr>";

  while($row = $result->fetch_assoc()) {
	                echo "<tr style='vertical-align:top;padding:10px;'>
					<td style='padding:10px;'>".$row['ser_name']."</td>
					<td style='padding:10px;'>".$row['charge']."</td>
					
					</tr>";
	
            }
echo "</table></div>";
       }
   }
    
	
}

$conn->close();
   ?>
