<!DOCTYPE html>

<html lang="en">
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>dbs project </title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet" />
       <!-- CUSTOM STYLE CSS -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
 </head>
<body>

<?php
session_start();
// establishing the MySQLi connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "datmart";
$status="";
$email="";
$pass="";
  
  

		// Create connection
		$con = new mysqli($servername, $username, $password, $dbname);
		if (mysqli_connect_errno())

		{

		echo "MySQLi Connection was not established: " . mysqli_connect_error();

		}

		// checking the user
		if(isset($_POST['login']))
		{
		$email = $_POST['email'];
		$pass = $_POST['pass'];

		$_SESSION["email"] = $email;
		$_SESSION["pass"] = $pass;


		$sql1 = "select s_name from shop where email= '" . $_SESSION['email'] . "' AND shop_id='" . $_SESSION['pass'] . "'";
		$result1 = $con->query($sql1);


		echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
		echo "<tr style='padding:10px;'>
		<th style='padding:10px;'>Update page</th>
		</tr>";
		$row1 = $result1->fetch_assoc();

		echo "<tr style='vertical-align:top;padding:10px;'>
					<td style='padding:10px;'>". "Welcome Back ".$row1['s_name']." User:"."</td></tr>";
		echo "</table></div>";

}

		if(isset($_POST['Submit_status']))
		{
					$status=$_POST["shop_status"];
					$_SESSION["shop_status"] = $status;
			
			
			
					$sql = "update shop set status = '".$_SESSION["shop_status"]."' where email = '".$_SESSION["email"]."'";
					$result1 = $con->query($sql);
					
					$sql1 = "select status from shop where email = '".$_SESSION["email"]."'";
					$result1 = $con->query($sql1);
					$row1 = $result1->fetch_assoc();

					
				echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
				echo "<tr style='padding:10px;'>
				<th style='padding:10px;'>Status</th>

					</tr>";
				echo "<tr style='vertical-align:top;padding:10px;'>
								<td style='padding:10px;'>".$row1['status']." </td>
								</tr>";
				echo "</table></div>";	
		}


		if(isset($_POST['Submit']))
		{
			$_SESSION["product"] =	$_POST["product"];

			$_SESSION["type"] = $_POST["type"];
			$_SESSION["price"] = $_POST["price"];
			$_SESSION["quantity"] = $_POST["quantity"];
	
			$sql2 = "update datmart.product set price = '".$_SESSION["price"]."' where p_name = '".$_SESSION["product"]."'";
			$result2 = $con->query($sql2);
			
			$sql2 = "select price from product where p_name = '".$_POST["product"]."'";
			
			$result2 = $con->query($sql2);
			$row2 = $result2->fetch_assoc();
			
			$sql3 = "update datmart.keeps set quantity = '".$_SESSION["quantity"]."' where product_id =(select
			product_id from product 
			where p_name = '".$_SESSION["product"]."')";
			$result3 = $con->query($sql3);
			
			$sql3 = "select quantity from datmart.keeps where product_id =(select
			product_id from product 
			where p_name = '".$_SESSION["product"]."')";
			
			$result3 = $con->query($sql3);
			$row3 = $result3->fetch_assoc();
			
		echo "<div><table border='1' bordercolor='blue' bgcolor='lightblue' style='font-size:18px;font-weight:bold;width:100%;padding:10px;'>";
		echo "<tr style='padding:10px;'>
			<th style='padding:10px;'>Product</th>
			<th style='padding:10px;'>Price</th>
			<th style='padding:10px;'>Quantity</th>

			</tr>";
		echo "<tr style='vertical-align:top;padding:10px;'>
						 <td style='padding:10px;'>'".$_SESSION["product"]."'</td> 		

						<td style='padding:10px;'>".$row2['price']." </td> 		
						<td style='padding:10px;'>".$row3['quantity']." </td> 				
						
						</tr>";
		echo "</table></div>";	
}

?>
         <form method="post" action="" id="filter_form" >  
					  
		 <div style="margin-left: 30px; margin-top: 5px">
         <div style="position: relative;">
            <select name = "shop_status"  id = "shop" style="position: absolute; top: 10px; left: 100px;">
                    <option disabled selected value=""/>Choose
					<option value="shop_is_on" name = "shop_is_on">shop is on</option>
               		<option value="shop_is_off" name = "shop_is_off">shop is off</option>

            </select>
					<input type="submit" name="Submit_status"  style="margin-top:50px;margin-left:500px;" value="UPDATE" class="btn btn-primary btn-filter" style="margin-top:-10px;" />

					   </div>
                          </div>
		</form>
					
					
			</br>
			<form method="post" action="" id="filter_form" >  
					  
		 <div style="margin-left: 30px; margin-top: 5px">
         <div style="position: relative;">
		    <select name = "product" id = "prod"  style="position: absolute; top: 10px; left: 350px;"></br></br>
                    <option disabled selected value=""/>Choose
					<option value="lemon_biscuits" name = "lemon_biscuits">Lemon Biscuits</option>
               		<option value="choclate_sandwich" name = "choclate_sandwich">Choclate sandwich</option>

            </select>
			         <select name = "type" id = "typ"  style="position: absolute; top: 10px; left: 100px;">
                    <option disabled selected value=""/>Choose
					<option value="biscuits" name = "biscuits">Biscuits</option>
               		<option value="shampoo" name = "shampoo">Shampoo</option>
             </select>
			  <input  name="price" id = "pricee" style="position: absolute; top: 10px; left: 550px;"   type="number_format" />
			  <input  name="quantity" id = "quant"    style="position: absolute; top: 10px; left: 840px;"   type="number_format" />

			  <script language="JavaScript" type="text/javascript">
			function validate1()
			{
				var e=document.getElementById("shop");
				var opt=e.options[e.selectedIndex].value;
				if (opt=="shop_is_on" || opt=="shop_is_off")
				{
					var e=document.getElementById("prod").disabled=false;
					var e=document.getElementById("typ").disabled=true;
					var e=document.getElementById("pricee").disabled=false;
					var e=document.getElementById("quantity").disabled=false;

				}
				// else
				// {
					// var e=document.getElementById("cafe").disabled=true;
				// }
			}
			function validate2()
			{
				var e=document.getElementById("prod");
				var opt=e.options[e.selectedIndex].value;
				if (opt=="lemon_biscuits" || opt=="choclate_sandwich")
				{
					var e=document.getElementById("prod").disabled=false;
					var e=document.getElementById("typ").disabled=false;
					var e=document.getElementById("pricee").disabled=false;
					var e=document.getElementById("quant").disabled=false;
             	}
				
           }
			function validate3()
			{
				var e=document.getElementById("typ");
				var opt=e.options[e.selectedIndex].value;
				if (opt=="biscuits" || opt=="shampoo")
				{
					var e=document.getElementById("prod").disabled=false;
					var e=document.getElementById("typ").disabled=false;
					var e=document.getElementById("pricee").disabled=false;
					var e=document.getElementById("quant").disabled=false;
             	}
				
           }
		
				   
			</script>
			  
			  
			<input type="submit" name="Submit"  style="margin-top:50px;margin-left:500px;" value="UPDATE" class="btn btn-primary btn-filter" style="margin-top:-10px;" />

        </div>
    </div>
				</form>
			  
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="assets/plugins/bootstrap.min.js"></script>  
    <!-- CUSTOM SCRIPTS -->
    <script src="assets/js/custom.js"></script>
    </body>
</html>