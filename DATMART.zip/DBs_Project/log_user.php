<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>2my4edge login logout system </title>
<style type="text/css">
.contain { width:500px; margin:0 auto; border:2px green dashed; margin-top:15px; min-height:200px; padding:10px; }
input { font-size:15px; color:#06C; padding:10px; width:200px; margin-top:25px;   }
.labelname { font-size:20px; font-weight:bold; font-family:Tahoma, Geneva, sans-serif; color:#33C; padding:10px; }
#submit { width:100px; height:30px; padding:2px; background-color:#999;}
h2 { color:#F00; font-size:22px; background-color:#CCC; padding:10px; }
h4 { color:#333; font-size:18px;}
</style>
</head>
<body>

<div class="contain" align="center">

<form action="login.php" method="POST">
<label for="name" class="labelname"> YourEmail </label>

<input type="text" name="email" id="userid" required="required" /><br />
<label for="name" class="labelname"> Password </label>

<input type="password" name="pass" id="userid" required="required" /><br />
<input type="submit" name="login" value="Login"/>
</form>
</div>


</body>

</html>


